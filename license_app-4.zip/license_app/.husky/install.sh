#!/bin/sh
if [ -z "$husky_skip_install" ]; then
  cd -- "$(dirname -- "$0")" &&
  cd .. &&
  if ! command -v husky &> /dev/null; then
    npm install husky --save-dev 2>/dev/null || echo "npm not found, skipping husky installation"
  else
    husky install 2>/dev/null || true
  fi
fi
